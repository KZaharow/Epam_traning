package edu.epam.models.driver;
/**
 * @author konstantin Zaharov
 * The {@code DriversCategoryEnum} class includes variants of drv category variants
 */
public enum DriversCategoryEnum {
    CATEGORY_1,
    CATEGORY_2,
    CATEGORY_3,
    CATEGORY_4,
    CATEGORY_HI
}
