package edu.epam.models.driver;

/**
 * @author  konstantin Zaharov
 * IDriver define basic methods for class Orders
 */
public interface IDriver {
    //void closeOrder(Order order, Driver driver); ??
    void closeOrder();
}
